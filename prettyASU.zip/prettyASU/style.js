let divHeader = document.createElement('div'),
    courses = document.querySelector('#inst4');
divHeader.setAttribute('class', 'headerCont');
divHeader.innerHTML = `
    <section class="header">
        <div class="logo">АлтГУ</div>
        <div class="subLogo">образовательный портал</div>
        <div class="headMenu">
            <div class="headMenu__item coursesBlock">
                <div class="headMenu__text coursesTitle">
                    Курсы
                </div>
                <div id="cour"></div>
            </div>
            <div class="headMenu__item noticeBlock">
                <div class="headMenu__text noticeTitle">
                    Уведомления<br>
                    (не готово)
                </div>
                <div id="not"></div>
            </div>
            <div class="headMenu__item">
                <div class="headMenu__text">
                    Сообщения<br>
                    (не готово)
                </div>
            </div>
        </div>
        <div id="loginBlock"></div>
        <div id="verBlock">версия a.3</div>
    </section>
`;

let mainReg = document.querySelector('.region-main-content');

if (
    (mainReg.childNodes[3]).childNodes[2] = document.querySelector('.course-content')
) {
    mainReg.style.overflow = 'hidden!important';
}

document.getElementById('page-site-index').appendChild(divHeader);
document.getElementById('cour').appendChild(courses);

let login = document.querySelector('.login');

if (login) {
    document.getElementById('loginBlock').appendChild(login);
} else {
    document.getElementById('loginBlock').innerHTML = `
    <a href="https://portal.edu.asu.ru/login/logout.php?sesskey=OR9xueFGvJ" class="exit">Выйти из аккаунта</a>
    `;
}

let coursesBlock = document.querySelector('.coursesBlock'),
    coursesContent = document.getElementById('inst4');

coursesBlock.addEventListener('mouseover', () => {
    coursesContent.style.display = 'block';
    coursesContent.style.opacity = '1';
    document.querySelector('.coursesTitle').style.display = 'none';
})
    
coursesBlock.addEventListener('mouseout', () => {
    document.querySelector('.coursesTitle').style.display = 'block';
    coursesContent.style.opacity = '0';
    coursesContent.style.display = 'none';
})